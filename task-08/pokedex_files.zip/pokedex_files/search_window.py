from PySide6.QtWidgets import QWidget, QLabel, QLineEdit, QPushButton, QVBoxLayout, QApplication, QDialog, QGridLayout, QHBoxLayout, QSizePolicy
from PySide6.QtGui import QPixmap
from PySide6.QtCore import Qt
from PySide6.QtGui import QPalette, QColor
import requests
import os


def initUI(self):
        self.setWindowTitle("Pokédex")

# search_window

class SearchWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setFixedSize(850, 500)
        self.setWindowTitle("Pokédex")  
          

        # Setting up background image (landing.jpg)
        background_label = QLabel(self)
        pixmap = QPixmap("/home/sathvik/Desktop/Poke-Search/assets/landing.jpg")
        background_label.setPixmap(pixmap)
        background_label.setGeometry(0, 0, 850, 500)
        background_label.setStyleSheet("""
            QLabel {
                background-image: url('/home/sathvik/Desktop/Poke-Search/assets/landing.jpg');
                background-position: right top;
                background-repeat: no-repeat;
    }
""")

        # Creating a layout
        layout = QVBoxLayout(self)

        # Creating all widgets
        label1 = QLabel("<big>Welcome  to</big> <b><span style='color:yellow; font-size: 36px;'>Pokédex</span></b>", self)
        label1.setGeometry(50, 10, 600, 70)


        self.textbox = QLineEdit(self)
        self.textbox.setGeometry(50, 35, 80, 30)
        self.textbox.setPlaceholderText("Search pokemon's name here")
        self.textbox.setStyleSheet("""
            QLineEdit {
                background-color: white;
                border: 3px solid darkred;
                border-radius: 5px;
                padding: 5px;
                margin-right: 550px;
                margin-top: 20px;
                color: darkred; 
            }

        
            QLineEdit::placeholder {
                color: black;  
            }
""") 

        self.result_label = QLabel(self)  
        layout.addWidget(self.result_label)

        search_button = QPushButton("Search", self)
        search_button.setGeometry(50, 300, 160, 43)
        search_button.setStyleSheet("""
            QPushButton {
                background-color: black;
                color: white;
                border: 1px solid #BA263E;
                border-radius: 5px;
                font: bold 16px;
                text-align: center;
                padding: 5px;
                margin-top: 100px;
                margin-bottom: 25px;
                margin-right: 700px;
            }
            QPushButton:hover {
                background-color: darkred;
            }
        """)
        search_button.clicked.connect(self.search_pokemon)

        capture_button = QPushButton("Capture", self)
        capture_button.setGeometry(50, 350, 100, 43)  # Adjusted the width
        capture_button.setStyleSheet("""
            QPushButton {
                background-color: black;
                color: white;
                border: 1px solid #BA263E;
                border-radius: 5px;
                font: bold 16px;
                text-align: center;
                margin-bottom: 25px;
                margin-right: 700px;
                padding: 5px;
            }
            QPushButton:hover {
                background-color: darkred;  
            }
        """)
        capture_button.clicked.connect(self.capture_pokemon)

        capture_button.clicked.connect(self.capture_pokemon)

        display_button = QPushButton("Display", self)
        display_button.setGeometry(50, 400, 100, 43)  
        display_button.setStyleSheet("""
            QPushButton {
                background-color: black;
                color: white;
                border: 1px solid #BA263E;
                border-radius: 5px;
                font: bold 16px;
                text-align: center;
                margin-right: 700px;
                padding: 5px;
            }
            QPushButton:hover {
                background-color: darkred;  
            }                       
        """)
        display_button.clicked.connect(self.display_captured_pokemons)

        # Adding widgets to layout
        layout.addWidget(label1)
        layout.addWidget(self.textbox)
        layout.addWidget(search_button)
        layout.addWidget(capture_button)
        layout.addWidget(display_button)

        # Aligning buttons to the left
        layout.setAlignment(Qt.AlignLeft | Qt.AlignTop)

        # Setting layout for the main window
        self.setLayout(layout)

        # Directory to store captured Pokémon images
        self.capture_directory = "captured_pokemons"
        os.makedirs(self.capture_directory, exist_ok=True)


    def search_pokemon(self):
        pokemon_name = self.textbox.text()
        if pokemon_name:
            # Example API endpoint (replace with the actual endpoint)
            api_url = f"https://pokeapi.co/api/v2/pokemon/{pokemon_name.lower()}"
            response = requests.get(api_url)

            if response.status_code == 200:
                pokemon_data = response.json()

                # Extract and display relevant information 
                name = pokemon_data['name']
                abilities = ', '.join(ability['ability']['name'] for ability in pokemon_data['abilities'])
                types = ', '.join(type['type']['name'] for type in pokemon_data['types'])
                stats = ', '.join(f"{stat['stat']['name']}: {stat['base_stat']}" for stat in pokemon_data['stats'])

                # Display details on the GUI
                details_text = f"Name: {name}\nAbilities: {abilities}\nTypes: {types}\nStats: {stats}"
                self.result_label.setText(details_text)

            else:
                print(f"Failed to fetch data. Status Code: {response.status_code}")

    def capture_pokemon(self):
        pokemon_name = self.textbox.text()
        if pokemon_name:
            # Api endpoint
            api_url = f"https://pokeapi.co/api/v2/pokemon/{pokemon_name.lower()}"
            response = requests.get(api_url)

            if response.status_code == 200:
                pokemon_data = response.json()

                # Extract image URL and download the image 
                image_url = pokemon_data['sprites']['other']['official-artwork']['front_default']
                image_response = requests.get(image_url)

                if image_response.status_code == 200:
                    # Saveing the image to the capture directory
                    image_filename = f"{pokemon_name.lower()}.png"
                    image_path = os.path.join(self.capture_directory, image_filename)
                    with open(image_path, 'wb') as image_file:
                        image_file.write(image_response.content)

                    print(f"Captured {pokemon_name}!")

                else:
                    print(f"Failed to fetch image. Status Code: {image_response.status_code}")

            else:
                print(f"Failed to fetch data. Status Code: {response.status_code}")

    def display_captured_pokemons(self):
        captured_pokemons = os.listdir(self.capture_directory)

        if captured_pokemons:
            viewer = MyPokemons(captured_pokemons, self.capture_directory)
            viewer.exec_()


class MyPokemons(QDialog):
    def __init__(self, captured_pokemons, capture_directory):
        super().__init__()

        # Storing the capture folder
        self.captured_pokemons = captured_pokemons
        self.capture_directory = capture_directory  
        self.current_index = 0

        self.setWindowTitle("My Pokemons")
        self.setFixedSize(600, 600)  

        self.image_label = QLabel(self)
        self.image_label.setAlignment(Qt.AlignCenter)
        self.image_label.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)

        self.update_display()

        previous_button = QPushButton("Previous", self)
        previous_button.clicked.connect(self.show_previous)

        next_button = QPushButton("Next", self)
        next_button.clicked.connect(self.show_next)

        button_layout = QHBoxLayout()
        button_layout.addWidget(previous_button)
        button_layout.addWidget(next_button)

        main_layout = QVBoxLayout(self)
        main_layout.addWidget(self.image_label)
        main_layout.addLayout(button_layout)

        self.setLayout(main_layout)

    def update_display(self):
        if self.captured_pokemons:
            image_path = os.path.join(self.capture_directory, self.captured_pokemons[self.current_index])

            pixmap = QPixmap(image_path)
            pixmap = pixmap.scaledToWidth(500)  
            self.image_label.setPixmap(pixmap)

    def show_previous(self):
        if self.captured_pokemons:
            self.current_index = (self.current_index - 1) % len(self.captured_pokemons)
            self.update_display()

    def show_next(self):
        if self.captured_pokemons:
            self.current_index = (self.current_index + 1) % len(self.captured_pokemons)
            self.update_display()

    def exec_(self):
        super().exec_()


if __name__ == "__main__":
    import sys
    app = QApplication(sys.argv)
    window = SearchWindow()
    window.show()
    sys.exit(app.exec())

